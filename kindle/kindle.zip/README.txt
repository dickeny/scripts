
说明:
    将带有简单格式的TXT文件转换为带有目录、作者信息的mobi文件。
    然后就可以邮寄到free.kindle.com来下载啦

用法：
    (请保证 txt 文件与 txt2mobi.py 在同一个目录中）
    $ python txt2mobi.py  紫川.txt  罗浮.txt

依赖：
    jinja2
